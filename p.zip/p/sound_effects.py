import numpy as np
from biquad_filter import LPF
from biquad_filter import filter

def round_to_prime_number(x):
    prime_number = np.array([[   2,    3,    5,    7,   11,   13,   17,   19,   23,   29,   31,   37,   41,   43,   47,   53,   59,   61,   67,   71],
                             [  73,   79,   83,   89,   97,  101,  103,  107,  109,  113,  127,  131,  137,  139,  149,  151,  157,  163,  167,  173],
                             [ 179,  181,  191,  193,  197,  199,  211,  223,  227,  229,  233,  239,  241,  251,  257,  263,  269,  271,  277,  281],
                             [ 283,  293,  307,  311,  313,  317,  331,  337,  347,  349,  353,  359,  367,  373,  379,  383,  389,  397,  401,  409],
                             [ 419,  421,  431,  433,  439,  443,  449,  457,  461,  463,  467,  479,  487,  491,  499,  503,  509,  521,  523,  541],
                             [ 547,  557,  563,  569,  571,  577,  587,  593,  599,  601,  607,  613,  617,  619,  631,  641,  643,  647,  653,  659],
                             [ 661,  673,  677,  683,  691,  701,  709,  719,  727,  733,  739,  743,  751,  757,  761,  769,  773,  787,  797,  809],
                             [ 811,  821,  823,  827,  829,  839,  853,  857,  859,  863,  877,  881,  883,  887,  907,  911,  919,  929,  937,  941],
                             [ 947,  953,  967,  971,  977,  983,  991,  997, 1009, 1013, 1019, 1021, 1031, 1033, 1039, 1049, 1051, 1061, 1063, 1069],
                             [1087, 1091, 1093, 1097, 1103, 1109, 1117, 1123, 1129, 1151, 1153, 1163, 1171, 1181, 1187, 1193, 1201, 1213, 1217, 1223],
                             [1229, 1231, 1237, 1249, 1259, 1277, 1279, 1283, 1289, 1291, 1297, 1301, 1303, 1307, 1319, 1321, 1327, 1361, 1367, 1373],
                             [1381, 1399, 1409, 1423, 1427, 1429, 1433, 1439, 1447, 1451, 1453, 1459, 1471, 1481, 1483, 1487, 1489, 1493, 1499, 1511],
                             [1523, 1531, 1543, 1549, 1553, 1559, 1567, 1571, 1579, 1583, 1597, 1601, 1607, 1609, 1613, 1619, 1621, 1627, 1637, 1657],
                             [1663, 1667, 1669, 1693, 1697, 1699, 1709, 1721, 1723, 1733, 1741, 1747, 1753, 1759, 1777, 1783, 1787, 1789, 1801, 1811],
                             [1823, 1831, 1847, 1861, 1867, 1871, 1873, 1877, 1879, 1889, 1901, 1907, 1913, 1931, 1933, 1949, 1951, 1973, 1979, 1987],
                             [1993, 1997, 1999, 2003, 2011, 2017, 2027, 2029, 2039, 2053, 2063, 2069, 2081, 2083, 2087, 2089, 2099, 2111, 2113, 2129],
                             [2131, 2137, 2141, 2143, 2153, 2161, 2179, 2203, 2207, 2213, 2221, 2237, 2239, 2243, 2251, 2267, 2269, 2273, 2281, 2287],
                             [2293, 2297, 2309, 2311, 2333, 2339, 2341, 2347, 2351, 2357, 2371, 2377, 2381, 2383, 2389, 2393, 2399, 2411, 2417, 2423],
                             [2437, 2441, 2447, 2459, 2467, 2473, 2477, 2503, 2521, 2531, 2539, 2543, 2549, 2551, 2557, 2579, 2591, 2593, 2609, 2617],
                             [2621, 2633, 2647, 2657, 2659, 2663, 2671, 2677, 2683, 2687, 2689, 2693, 2699, 2707, 2711, 2713, 2719, 2729, 2731, 2741],
                             [2749, 2753, 2767, 2777, 2789, 2791, 2797, 2801, 2803, 2819, 2833, 2837, 2843, 2851, 2857, 2861, 2879, 2887, 2897, 2903],
                             [2909, 2917, 2927, 2939, 2953, 2957, 2963, 2969, 2971, 2999, 3001, 3011, 3019, 3023, 3037, 3041, 3049, 3061, 3067, 3079],
                             [3083, 3089, 3109, 3119, 3121, 3137, 3163, 3167, 3169, 3181, 3187, 3191, 3203, 3209, 3217, 3221, 3229, 3251, 3253, 3257],
                             [3259, 3271, 3299, 3301, 3307, 3313, 3319, 3323, 3329, 3331, 3343, 3347, 3359, 3361, 3371, 3373, 3389, 3391, 3407, 3413],
                             [3433, 3449, 3457, 3461, 3463, 3467, 3469, 3491, 3499, 3511, 3517, 3527, 3529, 3533, 3539, 3541, 3547, 3557, 3559, 3571]])

    x = round(x)

    prime_number = prime_number.reshape(500, 1)

    emin = abs(x - prime_number[0])
    y = prime_number[0]

    for i in range(1, 500):
        e = abs(x - prime_number[i])
        if  e < emin:
            emin = e
            y = prime_number[i]

    return y

def reverb(fs, reverb_time, level, x):
    length_of_x = len(x)
    y = np.zeros(length_of_x)

    tau = np.array([0.030, 0.035, 0.040, 0.045, 0.005, 0.0017])

    d = np.zeros(6)
    g = np.zeros(6)

    d[0] = round_to_prime_number(fs * tau[0])
    d[1] = round_to_prime_number(fs * tau[1])
    d[2] = round_to_prime_number(fs * tau[2])
    d[3] = round_to_prime_number(fs * tau[3])
    d[4] = round_to_prime_number(fs * tau[4])
    d[5] = round_to_prime_number(fs * tau[5])

    g[0] = np.power(10, -3 * (d[0] / fs) / reverb_time)
    g[1] = np.power(10, -3 * (d[1] / fs) / reverb_time)
    g[2] = np.power(10, -3 * (d[2] / fs) / reverb_time)
    g[3] = np.power(10, -3 * (d[3] / fs) / reverb_time)
    g[4] = 0.7
    g[5] = 0.7

    u0 = np.zeros(length_of_x)
    for n in range(length_of_x):
        if n - d[0] >= 0:
            u0[n] = g[0] * u0[n - int(d[0])] + x[n - int(d[0])]

    u1 = np.zeros(length_of_x)
    for n in range(length_of_x):
        if n - d[1] >= 0:
            u1[n] = g[1] * u1[n - int(d[1])] + x[n - int(d[1])]

    u2 = np.zeros(length_of_x)
    for n in range(length_of_x):
        if n - d[2] >= 0:
            u2[n] = g[2] * u2[n - int(d[2])] + x[n - int(d[2])]

    u3 = np.zeros(length_of_x)
    for n in range(length_of_x):
        if n - d[3] >= 0:
            u3[n] = g[3] * u3[n - int(d[3])] + x[n - int(d[3])]

    v0 = u0 + u1 + u2 + u3

    v1 = np.zeros(length_of_x)
    for n in range(length_of_x):
        if n - d[4] >= 0:
            v1[n] = g[4] * v1[n - int(d[4])] - g[4] * v0[n] + v0[n - int(d[4])]

    v2 = np.zeros(length_of_x)
    for n in range(length_of_x):
        if n - d[5] >= 0:
            v2[n] = g[5] * v2[n - int(d[5])] - g[5] * v1[n] + v1[n - int(d[5])]

    y = x + v2 * level

    return y

def distortion(fs, gain, level, x):
    length_of_x = len(x)
    y = np.zeros(length_of_x)

    fc = 2000
    Q = 1 / np.sqrt(2)
    a, b = LPF(fs, fc, Q)
    u0 = filter(a, b, x)

    ratio = 4

    u1 = np.zeros(length_of_x * ratio)
    for n in range(length_of_x):
        u1[(n - 1) * ratio] = u0[n]

    fc = 20000 / ratio
    Q = 1 / np.sqrt(2)
    a, b = LPF(fs, fc, Q)
    u2 = filter(a, b, u1)

    u3 = np.zeros(length_of_x * ratio)
    for n in range(length_of_x * ratio):
        u3[n] = np.tanh(5 * u2[n] * gain / 2)

    fc = 20000 / ratio
    Q = 1 / np.sqrt(2)
    a, b = LPF(fs, fc, Q)
    u4 = filter(a, b, u3)

    for n in range(length_of_x):
        y[n] = u4[(n - 1) * ratio]

    y /= np.max(np.abs(y))
    y *= level

    return y

def compressor(threshold, width, ratio, x):
    length_of_x = len(x)
    y = np.zeros(length_of_x)

    gain = 1 / (threshold + (1 - threshold) / ratio)

    for n in range(length_of_x):
        if x[n] < 0:
            sign_of_x = -1
        else:
            sign_of_x = 1

        abs_of_x = np.abs(x[n])

        if abs_of_x < threshold - width / 2:
            abs_of_x = abs_of_x
        elif abs_of_x >= threshold - width / 2 and abs_of_x < threshold + width / 2:
            abs_of_x = abs_of_x + (1 / ratio - 1) * (abs_of_x - threshold + width / 2) * (abs_of_x - threshold + width / 2) / (width * 2)
        elif abs_of_x >= threshold + width / 2:
            abs_of_x = threshold + (abs_of_x - threshold) / ratio

        y[n] = sign_of_x * abs_of_x * gain

    return y
